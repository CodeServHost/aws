<header class="header">
    <div class="header-item py-1">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-3 col-sm-4 col-12">
                    <div class="logo">
                        <img src="images/logo.png" alt="logo">
                    </div>
                </div>
                <div class="col-lg-9 col-sm-8 col-10">
                    <div class="mainu-item">
                        <div class="phone">
                            <a href="tel:+18004010824">
                                <i class="fa-solid fa-phone icon"></i>&nbsp;&nbsp;Call Us: +18004010824
                            </a>
                        </div>
                        <div class="mail">
                            <a href="mailto:sales@theflightzon.com">
                                <i class="fa-solid fa-envelope icon"></i>&nbsp;&nbsp;sales@theflightzon.com
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</header>