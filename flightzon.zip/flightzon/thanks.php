<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>speedyyholiday </title> 
	<!-- Global site tag (gtag.js) - Google Ads: 10971547307 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-10971547307"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-10971547307');
</script>
<!-- Event snippet for Submit lead form speedyy conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-10971547307/H6CPCIPXy9oDEKuN0u8o'});
</script>
	
    <?php include("includes/top-css.php");?>
</head>

<body>
<//?php include("includes/header.php");?>
<//?php include("includes/footer.php");?>
<section class="thanks-sec">
    <h1>Thank you for contacting us. We will get back to you soon.</h1>
    <a href="index.php" class="go-back-btn">Go Back To Home</a>
</section>
</body>